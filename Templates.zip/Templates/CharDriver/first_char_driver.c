#include <linux/module.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>

static dev_t first; // Global variable for the first device number

int open(struct inode *inode, struct file *filp) //locks the semaphore
{
	
	printk("Inside open entry point\n");
	//MOD_INC_USE_COUNT;
	return 0;
}

int release(struct inode *inode, struct file *filp) {
	printk ("Inside close entry point\n");
	//MOD_DEC_USE_COUNT;
	//up(&dev.sem);
	return 0;
}

ssize_t read(struct file *filp, char *buff, size_t count, loff_t *offp) {
	printk("Inside read entry point:\n");
	//k = copy_to_user(buff, dev.array, count);
	return 0;
}

ssize_t write(struct file *filp, const char *buff, size_t count, loff_t *offp) {	
	printk("Inside write entry point:\n");
	
		return 0;
}

struct file_operations fops = {
	read:		read,
	write:		write,
	open: 		open,
	release:	release
};

void scull_setup_cdev(dev_t *dev, int index)
{
	//int err, devno = MKDEV(scull_major, scull_minor + index);
	struct cdev cdev; 
    //int major =  MAJOR(dev);
    //int minor = MINOR(dev);
    printk(KERN_ALERT " inside setup cdev");
    printk(KERN_INFO "<Major, Minor>: <%d, %d>\n", MAJOR(dev), MINOR(dev));
	cdev_init(cdev, &fops);
	dev->cdev.owner = THIS_MODULE;
	dev->cdev.ops = &fops;
	err = cdev_add (cdev, dev, 1);
	/* Fail gracefully if need be. */
	if (err)
		printk(KERN_NOTICE "Error %d ", err);
}
static int __init ofcd_init(void) /* Constructor */
{
	int ret;

	printk(KERN_INFO "Namaskar: ofd registered");
	ret = alloc_chrdev_region(&first, 0, 3, "Shweta");
	
	printk(KERN_INFO "<Major, Minor>: <%d, %d>\n", MAJOR(first), MINOR(first));
	scull_setup_cdev(&first,0);
	return 0;
}



static void __exit ofcd_exit(void) /* Destructor */
{
	unregister_chrdev_region(first, 3);
	printk(KERN_INFO "Alvida: ofd unregistered");
}

module_init(ofcd_init);
module_exit(ofcd_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Anil Kumar Pugalia <email@sarika-pugs.com>");
MODULE_DESCRIPTION("Our First Character Driver");
